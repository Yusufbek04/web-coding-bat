package org.example.condigbat.service.implementation;

import lombok.RequiredArgsConstructor;
import org.example.condigbat.entity.Language;
import org.example.condigbat.error.ConsumerException;
import org.example.condigbat.payload.ApiResult;
import org.example.condigbat.payload.LanguageDTO;
import org.example.condigbat.repository.LanguageRepository;
import org.example.condigbat.service.serviceInt.LanguageService;
import org.example.condigbat.util.CommonUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LanguageServiceImpl implements LanguageService {

    private final LanguageRepository repository;


    @Override
    public ApiResult<LanguageDTO> add(LanguageDTO languageDTO) {
        if (languageDTO.getTitle()==null)
            throw new ConsumerException("title not found please enter title");

        if (repository.existsByTitle(languageDTO.getTitle()))
            throw new ConsumerException(languageDTO.getTitle()+" already exists");

        if (repository.existsByUrl(CommonUtils.makeUrl(languageDTO.getTitle())))
            throw new ConsumerException(CommonUtils.makeUrl(languageDTO.getTitle())+ " already exists");

        Language language = new Language();
        language.setTitle(languageDTO.getTitle());
        language.setUrl(CommonUtils.makeUrl(languageDTO.getTitle()));
        repository.save(language);
        return new ApiResult<>(true,"success save",languageDTO);
    }

    @Override
    public ApiResult<List<LanguageDTO>> getLanguages() {
        return new ApiResult<>(
                true,
                "list of language",
                languageToLanguageDTO(repository.findAll())
        );
    }

    @Override
    public ApiResult<LanguageDTO> getLanguage(Integer id) {
        Optional<Language> byId = repository.findById(id);
        if (byId.isEmpty())
            throw new ConsumerException("not found");
        return new ApiResult<>(true,
                "success find",
                languageToLanguageDTO(byId.get()));
    }

    @Override
    public ApiResult<Boolean> delete(Integer id) {
        Optional<Language> byId = repository.findById(id);
        if (byId.isEmpty())
            throw new ConsumerException("not found");
        repository.deleteById(id);
        return new ApiResult<>(
                true,
                "deleted",
                true
        );
    }

    @Override
    public ApiResult<LanguageDTO> edit(LanguageDTO languageDTO, Integer id) {

        Optional<Language> lang = repository.getLanguageByTitle(languageDTO.getTitle());

        if (repository.findById(id).isEmpty())
            throw new ConsumerException(id + " id not found , first create then update");

        if (lang.isPresent() && !Objects.equals(id, lang.get().getId()))
            throw new ConsumerException(languageDTO.getTitle() + " already exists");

        if (lang.isPresent() && !Objects.equals(id, lang.get().getId()))
            throw new ConsumerException(languageDTO.getTitle() + " already exists");

        Language language = new Language();
        language.setId(id);
        language.setTitle(languageDTO.getTitle());
        language.setUrl(CommonUtils.makeUrl(languageDTO.getTitle()));
        repository.save(language);
        languageDTO.setUrl(CommonUtils.makeUrl(languageDTO.getTitle()));
        return new ApiResult<>(true, "success edited", languageDTO);
    }

    private List<LanguageDTO> languageToLanguageDTO(List<Language> list) {
        List<LanguageDTO> res = new ArrayList<>();
        for (Language language : list) {
            res.add(new LanguageDTO(
                    language.getId(),
                    language.getTitle(),
                    CommonUtils.makeUrl(language.getUrl())
            ));
        }
        return res;
    }
    private LanguageDTO languageToLanguageDTO(Language language) {
        return new LanguageDTO(
                language.getId(),
                language.getTitle(),
                CommonUtils.makeUrl(language.getUrl())
        );
    }
}
