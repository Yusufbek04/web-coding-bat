package org.example.condigbat.error;


public class ConsumerException extends RuntimeException {

    public ConsumerException(String message) {
        super(message);
    }
}
