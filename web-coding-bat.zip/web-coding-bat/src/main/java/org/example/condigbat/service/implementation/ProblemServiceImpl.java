package org.example.condigbat.service.implementation;

import lombok.RequiredArgsConstructor;
import org.example.condigbat.entity.Problem;
import org.example.condigbat.entity.Section;
import org.example.condigbat.error.ConsumerException;
import org.example.condigbat.payload.ApiResult;
import org.example.condigbat.payload.ProblemDTO;
import org.example.condigbat.payload.SectionDTO;
import org.example.condigbat.repository.ProblemRepository;
import org.example.condigbat.repository.SectionRepository;
import org.example.condigbat.service.serviceInt.ProblemService;
import org.example.condigbat.util.CommonUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProblemServiceImpl implements ProblemService {

    private final ProblemRepository repository;

    private final SectionRepository sectionRepository;


    @Override
    public ApiResult<ProblemDTO> add(ProblemDTO problemDTO) {

        if (problemDTO.getTitle() == null)
            throw new ConsumerException("title is empty please enter the title");

        Optional<Problem> titleAndId = repository.getProblemByTitleAndSectionId(
                problemDTO.getTitle(),
                problemDTO.getSectionDTO().getId());

        if (titleAndId.isPresent())
            throw new ConsumerException(problemDTO.getTitle() + " already exists in " + titleAndId.get().getSection().getTitle());

        Optional<Section> byId = sectionRepository.findById(problemDTO.getSectionDTO().getId());
        if (byId.isEmpty())
            throw new ConsumerException(problemDTO.getSectionDTO().getId() + " id not found in section");

        Optional<Section> byId1 = sectionRepository.findById(problemDTO.getSectionDTO().getId());
        if (byId1.isEmpty())
            throw new ConsumerException("Error");


        Problem problem = new Problem();
        problem.setTitle(problemDTO.getTitle());
        problem.setSection(byId1.get());
        problem.setDescription(problemDTO.getDescription());
        problem.setMethodSignature(problemDTO.getMethodSignature());
        repository.save(problem);

        Optional<Problem> problemByTitleAndSectionId = repository.getProblemByTitleAndSectionId(problem.getTitle(), problem.getSection().getId());
        if (problemByTitleAndSectionId.isEmpty())
            throw new ConsumerException("?");
        Problem problem1 = problemByTitleAndSectionId.get();

        return new ApiResult<>(true, "success save", problemToProblemDTO(problem1));
    }

    @Override
    public ApiResult<List<ProblemDTO>> getProblems() {
        return null;
    }

    @Override
    public ApiResult<ProblemDTO> getProblem(Integer id) {
        return null;
    }

    @Override
    public ApiResult<Boolean> delete(Integer id) {
        return null;
    }

    @Override
    public ApiResult<ProblemDTO> edit(ProblemDTO problemDTO, Integer id) {
        return null;
    }


  /*  private List<Problem> problemsDTOToProblems(List<ProblemDTO> list) {
        List<Problem> res = new ArrayList<>();
        for (ProblemDTO problemDTO : list) {
            Section section = new Section();
            section.setId(problemDTO.getSectionDTO().getId());
            section.setTitle(problemDTO.getSectionDTO().getTitle());
            section.setDescription(problemDTO.getSectionDTO().getDescription());
            section.setLanguage(CommonUtils.languageDTOToLanguage(problemDTO.getSectionDTO().getLanguage()));
            section.setMaxRate(problemDTO.getSectionDTO().getMaxRate());
            Problem problem = new Problem();
            problem.setTitle(problemDTO.getTitle());
            problem.setSection(section);
            problem.setDescription(problemDTO.getDescription());
            problem.setMethodSignature(problemDTO.getMethodSignature());
            res.add(problem);
        }
        return res;
    }
*/

//    private Problem problemDTOToProblem(ProblemDTO problemDTO) {
//
//        Problem problem = new Problem();
//        problem.setTitle(problemDTO.getTitle());
//        problem.setSection(section);
//        problem.setDescription(problemDTO.getDescription());
//        problem.setMethodSignature(problemDTO.getMethodSignature());
//        return problem;
//    }

    private ProblemDTO problemToProblemDTO(Problem problem) {
        SectionDTO section = new SectionDTO();
        section.setId(problem.getSection().getId());
        section.setTitle(problem.getSection().getTitle());
        section.setDescription(problem.getSection().getDescription());
        section.setLanguage(CommonUtils.languageToLanguageDTO(problem.getSection().getLanguage()));
        section.setMaxRate(problem.getSection().getMaxRate());
        return new ProblemDTO(
                problem.getId(),
                problem.getTitle(),
                problem.getDescription(),
                problem.getMethodSignature(),
                section,
                null,
                null
        );
    }

}
