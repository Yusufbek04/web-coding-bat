package org.example.condigbat.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ApiResult<E> {

    private final boolean success;

    private final String message;

    private final E data;

    public ApiResult(boolean success, String message, E data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }


}
