package org.example.condigbat.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.condigbat.controller.way.SectionController;
import org.example.condigbat.payload.ApiResult;
import org.example.condigbat.payload.SectionDTO;
import org.example.condigbat.service.serviceInt.SectionService;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
@RestControllerAdvice
public class SectionControllerImpl implements SectionController {

    private final SectionService service;

    @Override
    public ApiResult<SectionDTO> add(SectionDTO sectionDTO) {
        log.info("Add method entered: {}", sectionDTO);

        ApiResult<SectionDTO> result = service.add(sectionDTO);

        log.info("Add method exited: {}", result);

        return result;
    }

    @Override
    public ApiResult<List<SectionDTO>> getSections() {
        return service.getSections();
    }

    @Override
    public ApiResult<SectionDTO> getSection(Integer id) {
        return service.getSection(id);
    }

    @Override
    public ApiResult<Boolean> delete(Integer id) {
        return service.delete(id);
    }

    @Override
    public ApiResult<SectionDTO> edit(SectionDTO sectionDTO, Integer id) {
        return service.edit(sectionDTO,id);
    }
}
