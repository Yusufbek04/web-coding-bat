package org.example.condigbat.entity.enums;

public enum RoleEnum {


    ROLE_USER,
    ROLE_ADMIN
}
