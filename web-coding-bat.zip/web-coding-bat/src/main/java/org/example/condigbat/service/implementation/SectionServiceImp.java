package org.example.condigbat.service.implementation;

import lombok.RequiredArgsConstructor;
import org.example.condigbat.entity.Language;
import org.example.condigbat.entity.Section;
import org.example.condigbat.error.ConsumerException;
import org.example.condigbat.payload.ApiResult;
import org.example.condigbat.payload.SectionDTO;
import org.example.condigbat.repository.LanguageRepository;
import org.example.condigbat.repository.SectionRepository;
import org.example.condigbat.service.serviceInt.SectionService;
import org.example.condigbat.util.CommonUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SectionServiceImp implements SectionService {

    private final SectionRepository repository;
    private final LanguageRepository languageRepository;


    @Override
    public ApiResult<SectionDTO> add(SectionDTO sectionDTO) {
        if (sectionDTO.getTitle() == null)
            throw new ConsumerException("title is empty please enter title");

        Optional<Section> byTitleAndId = repository.getSectionByTitleAndLanguageId(sectionDTO.getTitle(), sectionDTO.getLanguage().getId());

        if (byTitleAndId.isPresent())
            throw new ConsumerException(sectionDTO.getTitle() + " already exists in " + byTitleAndId.get().getLanguage().getTitle());

        Optional<Language> byId = languageRepository.findById(sectionDTO.getLanguage().getId());
        if (byId.isEmpty())
            throw new ConsumerException(sectionDTO.getLanguage().getId() + " id not found in language");

        String url = CommonUtils.makeUrl(byId.get().getTitle()) + "/" + CommonUtils.makeUrl(sectionDTO.getTitle());
        if (repository.existsByUrl(url))
            throw new ConsumerException(url + " url already exists");

        Optional<Language> byId1 = languageRepository.findById(sectionDTO.getLanguage().getId());
        if(byId1.isEmpty())
            throw new ConsumerException("error");


        Section section = new Section();
        section.setTitle(sectionDTO.getTitle());
        section.setUrl(url);
        section.setLanguage(byId1.get());
        section.setDescription(sectionDTO.getDescription());
        section.setMaxRate(sectionDTO.getMaxRate());
        repository.save(section);

        return new ApiResult<>(true, "success save",sectionToSectionDTO(section));
    }

    @Override
    public ApiResult<List<SectionDTO>> getSections() {
        return new ApiResult<>(
                true,
                "list of section",
                sectionToSectionDTO(repository.findAll())
        );
    }

    @Override
    public ApiResult<SectionDTO> getSection(Integer id) {
        Optional<Section> byId = repository.findById(id);
        if (byId.isEmpty())
            throw new ConsumerException("not found");
        return new ApiResult<>(true,
                "success find",
                sectionToSectionDTO(byId.get()));
    }

    @Override
    public ApiResult<Boolean> delete(Integer id) {
        Optional<Section> byId = repository.findById(id);
        if (byId.isEmpty())
            throw new ConsumerException(id + " id not found");
        repository.deleteById(id);
        return new ApiResult<>(
                true,
                "deleted",
                true
        );
    }

    @Override
    public ApiResult<SectionDTO> edit(SectionDTO sectionDTO, Integer id) {
        Optional<Section> lang = repository.getSectionByTitleAndLanguageId(sectionDTO.getTitle(),
                sectionDTO.getLanguage().getId());

        Optional<Section> empty = repository.findById(id);


        if(sectionDTO.getLanguage().getId()==null)
            throw new ConsumerException("please enter language id");
        Optional<Language> language = languageRepository.findById(sectionDTO.getLanguage().getId());

        if (language.isEmpty())
            throw new ConsumerException("language not found");

        if (empty.isEmpty())
            throw new ConsumerException(id + " id not found  first create then update");

        if (lang.isPresent() && !Objects.equals(id, lang.get().getId()))
            throw new ConsumerException(sectionDTO.getTitle() + " already exists");

        Section section = new Section();
        section.setId(id);
        section.setTitle(sectionDTO.getTitle()==null?
                empty.get().getTitle():
                sectionDTO.getTitle()
                );
        section.setUrl(sectionDTO.getUrl()==null ?
                CommonUtils.makeUrl(language.get().getTitle())+"/"+
                CommonUtils.makeUrl(sectionDTO.getTitle()==null
                                    ?empty.get().getTitle()
                                    :sectionDTO.getTitle())
               :sectionDTO.getUrl()
        );
        section.setDescription(sectionDTO.getDescription()==null?empty.get().getDescription(): sectionDTO.getDescription());
        section.setLanguage(CommonUtils.languageDTOToLanguage(sectionDTO.getLanguage()));
        section.setMaxRate(sectionDTO.getMaxRate()==null?empty.get().getMaxRate() : sectionDTO.getMaxRate());
        repository.save(section);
        return new ApiResult<>(true, "success edited", sectionDTO);
    }

    private List<SectionDTO> sectionToSectionDTO(List<Section> list) {
        List<SectionDTO> res = new ArrayList<>();
        for (Section section : list) {
            res.add(new SectionDTO(
                    section.getId(),
                    section.getTitle(),
                    CommonUtils.makeUrl(section.getUrl()),
                    section.getDescription(),
                    section.getMaxRate(),
                    CommonUtils.languageToLanguageDTO(section.getLanguage())
            ));
        }
        return res;
    }

    private SectionDTO sectionToSectionDTO(Section section) {
        return new SectionDTO(
                section.getId(),
                section.getTitle(),
                section.getUrl(),
                section.getDescription(),
                section.getMaxRate(),
                CommonUtils.languageToLanguageDTO(section.getLanguage())
        );
    }

}
